<template>
  <div id="app">
  </div>
</template>

<script>
export default {
  name: "app",
  mounted() {
    // we run our JavaScript here
  }
};
</script>

<style>

</style>

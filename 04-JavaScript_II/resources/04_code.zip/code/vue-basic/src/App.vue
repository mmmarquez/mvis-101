<template lang="html">
  <div id="app">
  </div>
</template>

<script>
export default {
  mounted() {}
};
</script>

<style lang="css">

</style>

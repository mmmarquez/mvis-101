console.log("I'm useful");
alert("Hello, world!");
// document.querySelector("p").style.background = "purple";

/*
    JavaScript goes here
    D3.js, etc.
*/

let hi = "hello!";
console.log(hi);
